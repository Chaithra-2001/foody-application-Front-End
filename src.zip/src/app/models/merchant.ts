import { Restaurant } from "./restaurant"

export type merchant={
    merchantEmailId:string,
    password:string,
    role:string,
    merchantName:string,
    location:string,
    phoneNumber:string,
    restaurants:Restaurant[]
}





