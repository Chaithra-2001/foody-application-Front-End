export type favdish={
    dishID:string,
    name:string,
    category:string,
    price:number,
    rating:number
}