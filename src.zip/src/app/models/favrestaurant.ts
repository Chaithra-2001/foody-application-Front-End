import { Dish } from "./dishes"

export type Favrestaurant={
   
    restId:string,
    name:string,
    location:string,
    favoriteDish:Dish[]
 
}